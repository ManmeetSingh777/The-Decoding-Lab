# What is NOT yet proven (and NO REAL SPEND)

**No real spend.** This run made zero Anthropic or Runware calls, uploaded zero source frames and opened no provider socket. Every drill
used `vme/testing/simulated_anthropic.py:SimulatedAnthropicClient` and `vme/providers/gateway.py:OfflineRecordingTransport`
(labelled SIMULATED / OFFLINE FIXTURE). The real workspace has no authorizations, no jobs and no frame-vision rows
(`FILM_SOURCE_STATUS/SOURCE_ROLE_AND_SIXTH_BOUNDARY_STATUS.json:no_real_spend`). Claude Code subscription usage does NOT cover API
calls made through the `anthropic` SDK: a separate API account, key and spend authorization would be needed.

| Area | Status | Exact next action |
|---|---|---|
| Real vision perception of the 15+1 selected intervals | UNPROVEN — nothing real was seen | user confirms sources + 6th boundaries; authorize a SMALL canary with explicit model/price/cap and source-upload consent |
| Anthropic live API shape (`output_config.effort`, image limits, pricing $4/$20 per MTok from a cached table) | OFFLINE_CONTRACT_VALIDATED only | authorized `models.retrieve` + one tiny batch canary |
| Runware `runware:400@4` live behaviour (base64 vs URL, cost field, reference-image limit, getResponse states) | OFFLINE_CONTRACT_VALIDATED only (doc-cited, strict fake) | user confirms model/account; one authorized probe image |
| Artistic quality of any generated image | ART_QUALITY_UNPROVEN | real original art + human review |
| Correctness of a VLM's artistic interpretation | UNPROVEN; sufficiency gate checks structure/relations, not truth | calibration on a small real witness set with human review |
| Base five films' identity | BLOCKED_SOURCE_CONFIRMATION (titles differ from the contract; all 720p) | user confirms or supplies the intended films |
| Sixth clip volcano start / Earth-logo arrival | BLOCKED: boundaries unlocked (role confirmed by the user) | user views the local witness frames and locks both frames |
| Layers / masks / clean plates / hidden surfaces / IK | BLOCKED_ROUTE_NOT_IMPLEMENTED (named blocker per demand) | verified segmentation + clean-plate provider route |
| Expressions without an evidenced decision | BLOCKED_NO_DECISION_OR_OPERATOR | real source evidence for the expression choice |
| Professional multi-actor animation | UNPROVEN — WHOLE_STATE_SWAP only; directed graph consumer exists | approved real art + asset routes |
| Still transfer / animated transfer | still: pending human review; animated: NOT_ATTEMPTED | frozen skill + sealed unseen briefs + human review |
| Reference-exemplar upload of real source frames | BLOCKED without `ReferenceExemplarConsent` + Runware source-upload consent | explicit user consent per film SHA |
