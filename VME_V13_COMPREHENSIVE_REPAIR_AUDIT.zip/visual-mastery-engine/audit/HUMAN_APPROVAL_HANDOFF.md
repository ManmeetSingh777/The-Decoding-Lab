# Human-approval handoff (what only the user can do next)

Nothing below was done by the agent. Exact current state: `FILM_SOURCE_STATUS/SOURCE_ROLE_AND_SIXTH_BOUNDARY_STATUS.json`.

1. **Confirm the five BASE_FILM files by SHA256** (or supply the intended films; 1080p originals would be NEW sources):
   `vme confirm-role --sha <sha256> --role BASE_FILM --by <your name>` — the REAL loop stops at `SOURCE_ROLES_UNCONFIRMED` until then.
2. **Lock the sixth interval** after viewing the local witness frames: volcano first frame and Earth-logo arrival frame
   (`vme selection sixth-lock --start <i> --end <j> --confirmed-by <name> --witness-sha <packet sha>`). The loop stops at `SIXTH_BOUNDARY_NOT_LOCKED`; 15 sequences alone never run.
3. **Approve the 15-window selection** (`vme approve-selection --manifest-sha <sha> --by <name>`) after reviewing the proposal.
4. **Choose/confirm the vision model and price**, then issue a capped authorization with the confirmation phrase
   `I AUTHORIZE PAID CALLS WITHIN THIS CAP` and explicit source-upload consent listing film SHAs — only for a small canary first:
   `vme provider confirm-vision --model <id> --by <name>`, then `vme authorize --provider anthropic-claude --model <id> --tasks source_vision
   --cap-usd <cap> --issued-by <name> --confirm "I AUTHORIZE PAID CALLS WITHIN THIS CAP" --source-upload-consent --allowed-sources <sha,...>`.
5. **Confirm the Runware account/model** `runware:400@4`, a cost estimate per image, and (separately) whether source-frame exemplars
   may be uploaded as reference images: `vme provider confirm-runware --model runware:400@4 --est-cost-usd <x> --by <name>` and
   `vme reference-consent --film-sha <sha> --by <name> --statement "..."`. Keys stay in your local environment only.
6. **Review real original art** (S6), **assets** (S7) and **video** (S9); attribute each defect to a decision id so the responsible
   production choice is reopened. Freeze the skill only after review.
7. **Reconcile any uncertain paid submission** shown by `exact_next_operation` (`RECONCILE_VISION_SUBMISSION` / `RECONCILE_PROVIDER_JOB`)
   before anything is retried.
