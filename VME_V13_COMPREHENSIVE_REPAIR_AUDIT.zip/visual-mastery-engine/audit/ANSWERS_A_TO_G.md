# Addendum 28 final non-regression answers (A–G)

All reproduction commands run from `visual-mastery-engine/` with the pinned venv. Outputs cited are in this audit folder.
Limitation common to all: the drills use SIMULATED transports and SYNTHETIC films — they prove routing, not perception.

## A. Every target frame, neighbours, byte identity; whole→details→whole, temporal, cross-film contrast
* Code: `vme/vision/runner.py:plan_packets` (contiguous target packets covering exactly [start..end], context frames separate) →
  `PacketRunner._inputs` (decodes every frame, checks `raw_sha == frame_content_sha256`, records PNG sha/PTS) →
  `vme/vision/prompt.py:build_vision_request` (typed binding: `target_images[{frame_id, pts, bytes_sha}]`, prior boundary, active cluster,
  controlling problem) → `vme/vision/claude_adapter.py:submit` (each image preceded by `FRAME <id> [TARGET|CONTEXT] image_sha=...`) →
  `vme/vision/contracts.py:validate_packet_response` (one record per target, echoed image hash, persistent/ended identities,
  boundary events reconciled; empty/generic entries rejected). Instructions: `vme/vision/protocol.py:P0` ("WHOLE -> PARTS -> WHOLE",
  temporal alternatives) + `PASSES['P1']`; cross-film contrast: `vme/loop/real.py:_pick_witnesses` (one witness per film + contrast
  witnesses from other films/subject classes) used by `_s2` questions; P2/P5 in `protocol.py`.
* Reproduce: `python -m pytest tests/test_investigation_standard.py -k "protocol or every_frame or packet_request" -q`
* Output: `ART_INVESTIGATION_STANDARD_TRACE.json` (`packet_request_binding`, `one_per_frame_record`).
* Limitation: a model may still perceive wrongly; packet image count (20) is a planning assumption until `models.retrieve` is authorized.

## B. A feature absent from the atlas
* Code: per-frame `unexplained_phenomena` (required field, `contracts.py`) → `vme/loop/real.py:_register_phenomena` (one
  `VisualPhenomenon` per distinct behaviour, sightings accumulated across sequences) → `_phenomena_gaps` (a gap owned by the phenomenon
  id, not a category) → `_s2` question / `_reinspect` (crops + neighbours) → decision whose `owned_choice_ids` contains the phenomenon id;
  it counts as explained only when that decision is executable.
* Reproduce: `python -m pytest tests/test_production_choices.py -k reinspection -q`; drill evidence `DYNAMIC_REINSPECTION/`.
* Limitation: discovery depends on the vision model flagging the phenomenon; the simulated client flags one synthetic case.

## C. Missing face×view×light / hand×prop×body relation in a filled grid
* Code: `vme/style/coverage.py:reverse_plan` emits joint choices (`<actor>:face+view+light`, `<actor>:contact+light`);
  `VisualModelCompletenessInvestigator.investigate` requires a SUPPORTED relation WITH witness evidence AND a decision that OWNS the joint id
  (`owns`); `set_relation` refuses SUPPORTED with empty evidence. `_s2` turns the controlling gap into one question
  (`LoopController.step_question`), sends the witnesses that show all joint dimensions (`_pick_witnesses`), and asks for branches whose
  operation is `op.face_view_state` / `op.hand_prop_contact` (`_required_branches`); the answer changes those operators' clauses/references.
* Reproduce: `python -m pytest tests/test_production_choices.py -k case4 -q` (filled grid still reports `hero:face+view+light`,
  `hero:contact+light`, `hero:face+view`).
* Output: `DYNAMIC_QUESTION_AND_GAP_QUEUE.json`.
* Limitation: the drill's simulated answers are deterministic text; real answers need real frames.

## D. Two same-category observations
* Code: `vme/style/authoring.py:production_choice_id(owned_key, phenomenon)` → `author_decision(decision_id=..., owned_choice_ids=...)`;
  same decision re-answered with a different action → `contradictions` (both witness sets, status OPEN → RESEARCH_ONLY); human rejection →
  `superseded_branches`. Each branch gets its own clause `K-<decision>-<i>@<op>` and reference role `exemplar:<decision>:<hash>`;
  `_package_references` stores the exemplar bytes by sha with witness/film/consent.
* Reproduce: `python -m pytest tests/test_production_choices.py -k "same_category or contradiction" -q`
* Output: `SOURCE_FACT_TO_SKILL_TO_REQUEST.json` (two decisions, identical dimension tags, distinct ids, two clauses, two reference shas).
* Limitation: identity quality depends on the reverse plan / phenomenon naming; equivalent phenomena described differently stay separate.

## E. Skill-owned instructions to Runware without a second LLM
* Code: `vme/compiler/compiler.py:StyleProgramCompiler.compile` (CONTENT segments from typed brief slots; STYLE segments only from skill
  clauses; references from the skill manifest; `includeCost`, `outputType`, `outputFormat` technical) → `vme/providers/gateway.py:StyleImageGateway.submit`
  (only accepts issued jobs, recompiles and refuses any mutation, `interface_two_audit` field ownership) → `RunwareAdapter.build_body` (UUIDv4).
  Character states use the same path with the approved canonical bytes as identity reference (`skills/runtime.execute`, `_s7`).
  Static AST scan: only `compiler.py` builds a `positivePrompt` dict; only gateway/runware call `send`.
* Reproduce: `python -m pytest tests/test_compiler_authority.py tests/test_provider_contracts.py -q`
* Output: `REAL_EVIDENCE_TO_REQUEST/...TRACE.json:7_compiled_job_and_provider_body` (redacted provider-visible body), `REQUEST_PROVIDER_CONTRACTS/`.
* Limitation: the provider's own pixel choices remain uncontrolled (`provenance.RESIDUAL_NOTICE`).

## F. A new coding model reading only CONTINUE_HERE
* Code: `vme/state/capsule.py:import_and_verify` — hash-verifies every file, `verify_protocol` (identical sha or recorded migration with
  calibration report, else `PROTOCOL_DRIFT`), rebinding films by SHA only, uncertain charges block, recompiles the pinned job and compares
  the logical hash + reference hashes byte-for-byte, writes a factual `HandoffReconstruction` (no new rules), returns the first uncommitted
  operation. Old decisions are versioned records; a different interpretation becomes a contradiction/competing hypothesis
  (`protocol.competing_hypothesis`), never an overwrite. `PacketRunner` refuses to recount committed frames; image resolution policy is in
  `model_profile`.
* Reproduce: `python -m pytest tests/test_investigation_standard.py -k capsule -q`
* Output: `PORTABLE_INVESTIGATION_CAPSULE_TEST.json` (destination C rehearsal `byte_identical_logical_payload`, destination D
  `BLOCKED_MISSING_EVIDENCE` when reference bytes are removed).
* Limitation: a new model's *perceptual* regression can only be detected on a real calibration witness set (not available offline).

## G. Status by capability (no relabelling)
* Engineering-complete on strict offline fakes: R01–R13, R15–R18, R21, R22, R24 and ST28 items with PASS in `CRITICAL_REPAIR_CROSSWALK.json`
  (totals BLOCKED=1, PASS=41, UNPROVEN=6).
* Awaiting real vision/model proof: perception of the 15+1 intervals, VLM artistic interpretation quality (ST28-04/09), provider live
  behaviour, image quality (ST28-14), transfer (R23).
* Blocked: source confirmation (R14: base five unconfirmed, 720p), sixth boundary lock, layers/masks/clean plates (R19), expressions without
  evidenced decisions, professional multi-actor animation (R20), all human approvals and any paid call.
* Measured test results: repo `227 passed in 2588.80s (0:43:08)`; fresh extraction `225 passed, 2 skipped in 2753.46s (0:45:53)`.
