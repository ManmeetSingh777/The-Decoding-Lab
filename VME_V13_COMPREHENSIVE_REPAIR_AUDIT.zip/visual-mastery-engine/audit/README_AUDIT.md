# VME v1.3 — Comprehensive root-cause repair + Addendum 28 — audit index

Generated 2026-11-15T13:34:14+00:00 by `python -m vme.audit.comprehensive` (every JSON below was produced by running the repaired code).
**No paid call, no source upload, no network request was made.** All drills use SIMULATED vision/image transports on SYNTHETIC
films; they prove software wiring only — not artistic learning, image quality or real provider behaviour.

* Tests in repo: `227 passed in 2588.80s (0:43:08)` (passed=227) — logs `logs_repo/`, cases `TEST_RESULTS_REPO.json`.
* Tests in a fresh extraction of this ZIP's own source: `225 passed, 2 skipped in 2753.46s (0:45:53)` (passed=225, skipped=2) — `logs_fresh_extraction/`, `TEST_RESULTS_FRESH_EXTRACTION.json`.
* R01–R24 + ST28-01..24 status totals: BLOCKED=1, PASS=41, UNPROVEN=6 — `ROOT_CAUSE_MATRIX.json`, `CRITICAL_REPAIR_CROSSWALK.json`.

| Folder / file | What it proves (offline) |
|---|---|
| `REQUEST_PROVIDER_CONTRACTS/` | Anthropic batch payload with ≤64-char ids; strict fake rejections; Runware strict rejections (uuid5, no includeCost, 5 refs…); getResponse classification |
| `CRASH_AND_COST/` | 2 hard kills (vision accepted-before-batch-id; image sent-before-receipt), concurrent reservations, human reconciliation |
| `REAL_EVIDENCE_TO_REQUEST/` | frame → witness → question → decision → skill version → reference bytes → compiled provider body |
| `SOURCE_FACT_TO_SKILL_TO_REQUEST.json` | two same-category decisions survive as two decisions; exemplar-byte mutation changes payload; missing consent/bytes refuse |
| `DYNAMIC_REINSPECTION/` | SYNTHETIC unexplained phenomenon → crop + neighbour reinspection → new witnesses; an unanswerable gap stays unresolved |
| `DYNAMIC_QUESTION_AND_GAP_QUEUE.json` | one controlling question chosen from many queued gaps; question steps |
| `ITERATION_INVALIDATION/` | human art rejection → reopened decision → only S2–S5 rerun → new skill hash → different request (prompt diff) |
| `ASSET_MANUFACTURING/` | asset contracts (hash/size/alpha/coordinates/consumers), world plate without actor; expression/layer/clean-plate demands blocked by name |
| `FILM_SOURCE_STATUS/` | real six-file hashes, true 1280×720 resolution, unconfirmed base five, unlocked sixth boundary, first human action, no-spend evidence |
| `ART_INVESTIGATION_STANDARD_TRACE.json` | protocol VME-A28-1 + sha, pass→code map, packet binding, one per-frame record |
| `PORTABLE_INVESTIGATION_CAPSULE_TEST.json`, `CAPSULE_EXAMPLE.json` | crash before decision publish → capsule → fresh destination verify/resume → byte-identical pinned compile; missing reference bytes block |
| `MODEL_STANDARD_DRIFT_TEST.json` | shallow-but-valid answer rejected for the producing choice; substantive alternative kept as competing hypothesis |
| `RED_BEFORE_GREEN_AFTER/` | reproducers run on the unmodified code (red) and the repaired code (green); the 2 previously failing tests |
| `CHANGED_FILES.diff`, `CODE_VERSION_HASHES.json` | exact source change since 651c75b and per-file hashes |
| `WHAT_IS_NOT_YET_PROVEN.md`, `ANSWERS_A_TO_G.md`, `HUMAN_APPROVAL_HANDOFF.md` | limits, the A–G answers, the next human decisions |
