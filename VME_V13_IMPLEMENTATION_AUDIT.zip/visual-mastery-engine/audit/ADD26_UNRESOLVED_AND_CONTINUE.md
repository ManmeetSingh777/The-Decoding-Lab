# Addendum 26 unresolved items and continuation

- Sixth source: PRESENT (by duration proposal, pending user confirmation). Locator status: CANDIDATE_BOUNDARIES_AWAITING_HUMAN_REVIEW.
- First-15 real selection: NOT_RUN — needs whole-artwork rationales (human or authorized VLM).
- Real per-frame VLM on 15+1 windows: BLOCKED_CONSENT (provider/price/upload consent absent).
- Next operation after audit approval: user confirms source roles + sixth boundaries, chooses VLM provider, authorizes upload + budget.
