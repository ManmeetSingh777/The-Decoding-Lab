# Unimplemented or blocked

Requirement totals (from executed tests): {"PASS": 192, "BLOCKED": 37}

## FAIL
- none observed

## NOT_BUILT / untested
- none

## BLOCKED (offline wiring/refusal proven; positive proof needs PAID / ART / HUMAN)
- A04 [PAID]: Provider capability call returns real file + cost
- A08 [ART]: Several ranked gaps with source+original witnesses
- A10 [PAID]: Specific observation with full context and producing decision
- A12 [PAID+ART]: Causality: disable/enable method changes intended output
- A13 [ART]: Multi-change attribution via toggles
- A15 [PAID+ART]: Controlled anchor A/B without confounds
- A16 [PAID+ART]: Rotating development brief, no manual rescue
- A17 [PAID+ART]: Blind transfer after freeze
- A18 [HUMAN+ART]: Human review sees stills/MP4/gaps; feedback saved
- A21 [ART]: Image-to-motion identity consistency
- A24 [PAID+ART+HUMAN]: Integrated approved iteration with 12–20 s MP4
- A25 [PAID+ART+HUMAN]: 20–30 s multi-shot film under frozen skills
- A28 [PAID]: All-frame VLM estimate + gated segmented execution
- A32 [ART]: Originality vs clone discrimination on outputs
- A37 [ART]: Visual prompt-output review on real images
- A38 [HUMAN+ART]: Canonical character human verdict tied to hashes
- A39 [ART]: Coherent multi-view/face identity
- A45 [ART]: First cycles emphasise characters with real art
- A58 [ART]: Character generated first as whole canonical art
- A59 [ART]: Canonical-conditioned face/pose/hand states
- A67 [ART+HUMAN]: User review on full-size art before layers/motion
- A68 [ART]: reference_impl tests pass; app pinned-skill→real request→real image
- B28 [ART]: Alternate view identity drift → route reexamined
- B29 [ART]: Weak actor art → no render
- B32 [ART]: One-scene improvement not transferable
- B33 [PAID+ART]: Skill can't produce visual difference reported
- B34 [ART]: Rich still but flat motion → no pan-only proof
- C17 [PAID]: Correct actual provider (live catalog/probe)
- C18 [PAID]: Real image bytes
- C19 [ART]: Artwork appealing at construction
- C20 [ART]: Character identity across poses
- C21 [ART]: Face/expression language
- C27 [ART]: Simultaneous world activity
- C28 [ART]: Perspective/attention continuity
- C32 [PAID+ART]: Reliable transfer
- ADD24-S0S4-REAL [PAID+ART+HUMAN]: First real learning iteration S0–S4 (after audit + consent)
- ADD25-L0-REAL [PAID]: Real first-15 per-frame VLM study (PHASE L0)

## Known engineering limits (truthful)
- No commercial VLM adapter is selected; `HttpVisionAdapter` is a generic, authorization-gated payload builder. Choosing a provider,
  verifying its multi-image/ID-mapping limits and price is the first post-audit task.
- Real first-15 selection cannot run offline: candidate windows exist from the local navigation survey, but whole-artwork rationales
  must come from a human or an authorized VLM (ADD25-S05). Status NEEDS_SELECTION_REVIEW / NOT_RUN.
- Sixth clip: role proposed by duration (≈6.8 min, "How to Make a Kurzgesagt Video in 1200 Hours.mp4") — PENDING USER CONFIRMATION;
  volcano-start / logo-entrance boundaries need the user's choice from the local witness packet (no classifier, no upload).
- `op.clean_plate` / `op.layer_extract` real implementations depend on provider edit/mask capability; the offline fixture uses a local
  fill on fixture rasters (wiring only). Real segmentation/matting model not chosen.
- Motion evidence is block-translation based: motion over textureless regions is not counted either way (documented limitation).
- Interface-I lexical grounding is a crude executable derivation check, not semantic proof that a clause follows from an observation.
- Artistic quality, identity consistency, transfer and video quality are UNEVALUATED (no real art exists).
