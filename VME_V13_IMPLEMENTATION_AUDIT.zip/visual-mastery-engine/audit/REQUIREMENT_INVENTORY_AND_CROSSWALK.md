# Requirement inventory and crosswalk

Generated 2026-11-14T23:23:51+00:00 from executed tests.

## Original approved 13 parts → modules

- **P01 Six connected responsibilities** → `vme.reference`, `vme.investigation.gaps`, `vme.investigation.controller`, `vme.skills`, `vme.providers.gateway`, `vme.review`
- **P02 High-impact gap identification** → `vme.investigation.gaps:rank_gaps/select_cluster`
- **P03 Question engine** → `vme.investigation.controller:derive_next_question`
- **P04 Working skill conversion** → `vme.style.decisions`, `vme.skills.skill`, `vme.compiler.compiler`
- **P05 Sequential lead + bounded parallel** → `vme.investigation.controller:LoopController`, `vme.reference.ingest:index_all (bounded threads)`
- **P06 Iteration protocol with user review gates** → `vme.loop.stages`, `vme.review.approvals`
- **P07 Fast learning, persistence** → `vme.state.store`, `vme.state.handoff`, `vme.vision.runner`
- **P08 Visual first, animation-aware** → `vme.artwork.character:derive_animation_demand`, `vme.render.renderer`
- **P09 No overfitting (anchor/rotating/unseen)** → `vme.experiments.experiments:HoldoutRegistry`
- **P10 Concrete engineering modules + CLI** → `vme.cli`
- **P11 First real learning cycle** → `vme.loop.stages (REAL mode stops at consent)`
- **P12 Failure diagnosis and stop policies** → `vme.diagnose.diagnose`, `vme.util.Blocked`
- **P13 Success gates (art/transfer/animation/integrated)** → `vme.review.approvals`, `vme.experiments.experiments:transfer_status`

## Every requirement ID

| ID | Status | Needs | Requirement | Module(s) | Tests |
|---|---|---|---|---|---|
| A01 | PASS |  | Fresh repo; no prior AnimationLab inputs | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 1 |
| A02 | PASS |  | Ingest sources: ffprobe, SHA256, decode | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| A03 | PASS |  | Targeted retrieval + native crops + adjacent sequence | vme.reference.frames; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| A04 | BLOCKED | PAID | Provider capability call returns real file + cost | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 1 |
| A05 | PASS |  | No paid call without budget; no upload without consent | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| A06 | PASS |  | Scene/asset schema validation | vme.review.approvals, vme.review.server, vme.render.renderer; vme.audit.contracts | 2 |
| A07 | PASS |  | Renderer refuses before approvals; ffprobe-verified MP4 after | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A08 | BLOCKED | ART | Several ranked gaps with source+original witnesses | vme.investigation.controller, vme.investigation.gaps | 1 |
| A09 | PASS |  | Connected cluster with dependencies and exclusions | vme.investigation.controller, vme.investigation.gaps | 1 |
| A10 | BLOCKED | PAID | Specific observation with full context and producing decision | vme.investigation.controller, vme.investigation.gaps | 1 |
| A11 | PASS |  | Skill conversion: executable recipe consumed by producer | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A12 | BLOCKED | PAID+ART | Causality: disable/enable method changes intended output | vme.experiments.experiments, vme.diagnose.diagnose | 2 |
| A13 | BLOCKED | ART | Multi-change attribution via toggles | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A14 | PASS |  | Multiple-root diagnosis separates causes | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A15 | BLOCKED | PAID+ART | Controlled anchor A/B without confounds | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A16 | BLOCKED | PAID+ART | Rotating development brief, no manual rescue | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A17 | BLOCKED | PAID+ART | Blind transfer after freeze | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A18 | BLOCKED | HUMAN+ART | Human review sees stills/MP4/gaps; feedback saved | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A19 | PASS |  | Kill/restart after partial provider request; no duplicate bill | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.loop.stages, vme.state.handoff; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 8 |
| A20 | PASS |  | Per-run cost accounting, unknown costs explicit | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 1 |
| A21 | BLOCKED | ART | Image-to-motion identity consistency | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A22 | PASS |  | Unsupported capability → named stop | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 5 |
| A23 | PASS |  | Separate PASS/FAIL/UNTESTED statuses | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A24 | BLOCKED | PAID+ART+HUMAN | Integrated approved iteration with 12–20 s MP4 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A25 | BLOCKED | PAID+ART+HUMAN | 20–30 s multi-shot film under frozen skills | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A26 | PASS |  | Every decoded frame + PTS indexed; VFR kept | vme.audit.contracts; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 4 |
| A27 | PASS |  | Coverage ledger separates indexed/sent/verified/native | vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| A28 | BLOCKED | PAID | All-frame VLM estimate + gated segmented execution | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| A29 | PASS |  | Corrupt/skipped/VFR/last-frame injection caught | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 3 |
| A30 | PASS |  | Style mechanism vs source fact | vme.style.decisions, vme.investigation.evidence | 1 |
| A31 | PASS |  | Cross-subject conditions and counterexamples | vme.style.decisions, vme.investigation.evidence | 1 |
| A32 | BLOCKED | ART | Originality vs clone discrimination on outputs | vme.style.decisions, vme.investigation.evidence | 1 |
| A33 | PASS |  | Every style clause traces to skill; content to brief | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| A34 | PASS |  | Clause coverage/contradiction; nothing silently dropped | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A35 | PASS |  | Prompt length/reference count/dimension validation | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| A36 | PASS |  | Skill change → request change (and output where feasible) | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A37 | BLOCKED | ART | Visual prompt-output review on real images | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A38 | BLOCKED | HUMAN+ART | Canonical character human verdict tied to hashes | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A39 | BLOCKED | ART | Coherent multi-view/face identity | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A40 | PASS |  | Limb/hand/prop/ground relationship validation | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 13 |
| A41 | PASS |  | Layer/mask/clean-plate recomposition | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 15 |
| A42 | PASS |  | Artwork approval gate; rejected art cannot render | vme.review.approvals, vme.review.server, vme.render.renderer | 3 |
| A43 | PASS |  | Asset pack approval gate | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| A44 | PASS |  | Reapproval after replacement | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| A45 | BLOCKED | ART | First cycles emphasise characters with real art | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A46 | PASS |  | Independent multi-failure diagnosis | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A47 | PASS |  | Resume keeps approvals/pending reviews/idempotency | vme.review.approvals, vme.review.server, vme.render.renderer; vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.loop.stages, vme.state.handoff; vme.audit.contracts | 5 |
| A48 | PASS |  | Separate claim statuses; tests ≠ mastery | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A49 | PASS |  | Scene facts separated before skill writing | vme.style.decisions, vme.investigation.evidence | 1 |
| A50 | PASS |  | Question ladder does not stop on adjectives | vme.style.decisions, vme.investigation.evidence | 1 |
| A51 | PASS |  | Decisions carry applicability/variants/exclusions/freedoms | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.style.decisions, vme.investigation.evidence | 2 |
| A52 | PASS |  | Design plan + recipe exist before provider call | vme.style.decisions, vme.investigation.evidence | 1 |
| A53 | PASS |  | Runtime style insertion cannot change request | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A54 | PASS |  | Missing essential decision blocks; no default style | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| A55 | PASS |  | Stage-specific operations (canonical vs pose vs grip) | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A56 | PASS |  | Style-like language in brief separated/rejected | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A57 | PASS |  | Reference slots by skill rules and capability; identity bytes | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| A58 | BLOCKED | ART | Character generated first as whole canonical art | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A59 | BLOCKED | ART | Canonical-conditioned face/pose/hand states | vme.artwork.raster, vme.artwork.assets, vme.artwork.character; vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 3 |
| A60 | PASS |  | AnimationDemandPlan before art generation | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A61 | PASS |  | Every frame decoded; per-frame VLM truthfully separate | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 9 |
| A62 | PASS |  | Per-frame semantic entries; summary rejected | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 7 |
| A63 | PASS |  | Boundary state across packets | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| A64 | PASS |  | Semantic replay across new session | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 8 |
| A65 | PASS |  | Idempotent/reconciled paid requests | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 8 |
| A66 | PASS |  | Two-film-first vs all-five accurate reporting | vme.reference.probe, vme.reference.frame_index, vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| A67 | BLOCKED | ART+HUMAN | User review on full-size art before layers/motion | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A68 | BLOCKED | ART | reference_impl tests pass; app pinned-skill→real request→real image | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B01 | PASS |  | Only allowed MP4s in provenance | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 1 |
| B02 | PASS |  | Frame index+PTS hash exact | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 1 |
| B03 | PASS |  | Index all, VLM exactly zero | vme.reference.frames; vme.reference.probe, vme.reference.frame_index, vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 3 |
| B04 | PASS |  | Missing frame in vision result → no commit | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| B05 | PASS |  | Input hash mismatch → quarantine | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| B06 | PASS |  | Kill around paid request; no duplicate | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 8 |
| B07 | PASS |  | Kill after response before commit | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| B08 | PASS |  | New session from CONTINUE_HERE+DB | vme.loop.stages, vme.state.handoff; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| B09 | PASS |  | Vague 'polished' → targeted cause | vme.investigation.controller, vme.investigation.gaps; vme.style.decisions, vme.investigation.evidence | 2 |
| B10 | PASS |  | Source noun in decision demoted | vme.style.decisions, vme.investigation.evidence | 1 |
| B11 | PASS |  | Single source stays conditional | vme.style.decisions, vme.investigation.evidence | 1 |
| B12 | PASS |  | Connected world/character/colour cluster | vme.investigation.controller, vme.investigation.gaps | 1 |
| B13 | PASS |  | Question lacking producing unknown parked | vme.investigation.controller, vme.investigation.gaps | 1 |
| B14 | PASS |  | No exceptions/adaptations → not frozen | vme.style.decisions, vme.investigation.evidence | 1 |
| B15 | PASS |  | No operation → research-only | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.style.decisions, vme.investigation.evidence | 2 |
| B16 | PASS |  | SKILL.md-only refused | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B17 | PASS |  | Selected clause change changes prompt | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B18 | PASS |  | Non-selected prose change no effect | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B19 | PASS |  | Raw positivePrompt refused | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B20 | PASS |  | Style rewrite in brief → ticket/block | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B21 | PASS |  | Pose edit without identity refused | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B22 | PASS |  | Reference overflow staged or blocked | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B23 | PASS |  | '7B' without verified model refused | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 1 |
| B24 | PASS |  | No consent → network refused | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 3 |
| B25 | PASS |  | Opaque PNG never transparent | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B26 | PASS |  | Layer dimension/origin mismatch caught | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 14 |
| B27 | PASS |  | Hand/prop whole pose before layers | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B28 | BLOCKED | ART | Alternate view identity drift → route reexamined | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B29 | BLOCKED | ART | Weak actor art → no render | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B30 | PASS |  | Approved hash change invalidates | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| B31 | PASS |  | Multiple failures → separate trails | vme.experiments.experiments, vme.diagnose.diagnose; vme.investigation.controller, vme.investigation.gaps | 2 |
| B32 | BLOCKED | ART | One-scene improvement not transferable | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| B33 | BLOCKED | PAID+ART | Skill can't produce visual difference reported | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| B34 | BLOCKED | ART | Rich still but flat motion → no pan-only proof | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| B35 | PASS |  | Audit ZIP contents | vme.loop.stages, vme.state.handoff | 1 |
| B36 | PASS |  | Claims map to function/test/evidence | vme.audit.contracts | 1 |
| C01 | PASS |  | Fresh source allowlist | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| C02 | PASS |  | Accurate film/time/frames | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| C03 | PASS |  | True every-frame VLM availability | vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 3 |
| C04 | PASS |  | Native-detail inspection | vme.reference.frames; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 3 |
| C05 | PASS |  | Scene+temporal understanding (boundary, adjacency) | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| C06 | PASS |  | High-impact question selection | vme.investigation.controller, vme.investigation.gaps | 1 |
| C07 | PASS |  | Deep observation, not slogans | vme.investigation.controller, vme.investigation.gaps; vme.style.decisions, vme.investigation.evidence | 2 |
| C08 | PASS |  | Self-correcting questions | vme.investigation.controller, vme.investigation.gaps | 1 |
| C09 | PASS |  | Style independent of source subject | vme.style.decisions, vme.investigation.evidence | 1 |
| C10 | PASS |  | Style isn't just recurrence | vme.style.decisions, vme.investigation.evidence | 1 |
| C11 | PASS |  | Integration across disciplines | vme.style.decisions, vme.investigation.evidence | 1 |
| C12 | PASS |  | Manufacture plan exists | vme.style.decisions, vme.investigation.evidence | 1 |
| C13 | PASS |  | Skill is a working producer | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.loop.stages, vme.state.handoff | 2 |
| C14 | PASS |  | Style-exclusive prompt authority | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| C15 | PASS |  | New content vs learned style | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| C16 | PASS |  | Specific prompts without bloat | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| C17 | BLOCKED | PAID | Correct actual provider (live catalog/probe) | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 1 |
| C18 | BLOCKED | PAID | Real image bytes | vme.artwork.raster, vme.artwork.assets, vme.artwork.character; vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 7 |
| C19 | BLOCKED | ART | Artwork appealing at construction | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| C20 | BLOCKED | ART | Character identity across poses | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 2 |
| C21 | BLOCKED | ART | Face/expression language | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| C22 | PASS |  | Limb/hand/contact logic | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 14 |
| C23 | PASS |  | Part & layer usability | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 15 |
| C24 | PASS |  | Coordinate handoff | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 15 |
| C25 | PASS |  | Correct render tool | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C26 | PASS |  | Motion-aware art; no pan disguise | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| C27 | BLOCKED | ART | Simultaneous world activity | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C28 | BLOCKED | ART | Perspective/attention continuity | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C29 | PASS |  | Source→skill causality | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.experiments.experiments, vme.diagnose.diagnose | 2 |
| C30 | PASS |  | Multiple connected gaps | vme.investigation.controller, vme.investigation.gaps | 1 |
| C31 | PASS |  | Root-cause diagnosis | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| C32 | BLOCKED | PAID+ART | Reliable transfer | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| C33 | PASS |  | User approval before motion | vme.review.approvals, vme.review.server, vme.render.renderer | 4 |
| C34 | PASS |  | Complete evidence+budget | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 3 |
| C35 | PASS |  | Crash and timeout resume | vme.loop.stages, vme.state.handoff; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 12 |
| C36 | PASS |  | User can audit build | vme.review.approvals, vme.review.server, vme.render.renderer; vme.audit.contracts | 5 |
| C37 | PASS |  | Honest qualification | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C38 | PASS |  | No unauthorized source upload | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 3 |
| ADD24-E1 | PASS |  | Five-film mapping + cross-film sequence selection as code contracts | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD24-E2 | PASS |  | Character witness grouping, question traces, skill clauses, C1→C7 on synthetic fixtures | vme.loop.stages, vme.state.handoff | 2 |
| ADD24-E3 | PASS |  | Persistent semantic work units + export/import cold start | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-B1 | PASS |  | Cross-actor witness groups (a)–(f) | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| ADD24-B2 | PASS |  | Ten question families with required record fields | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| ADD24-D1 | PASS |  | Disk-owned workspace layout | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D2 | PASS |  | Atomic persistence at reasoning boundaries | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D3 | PASS |  | status/checkpoint/export-handoff/import-handoff/resume commands | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D4-1 | PASS |  | Kill mid-frame sequence; fresh process resumes exact next PTS | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| ADD24-D4-2 | PASS |  | Kill after provider submission; reconcile, no double charge | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 1 |
| ADD24-D4-3 | PASS |  | Kill between observation and skill conversion | vme.loop.stages, vme.state.handoff | 5 |
| ADD24-D4-4 | PASS |  | Kill during character pose generation | vme.loop.stages, vme.state.handoff | 6 |
| ADD24-D4-5 | PASS |  | Corrupt/drop asset or MP4 → import refuses complete | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D4-6 | PASS |  | Switch environment via handoff ZIP; reproduce compiled prompt bytes | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D4-7 | PASS |  | Review approval/rejection survives import | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-S0S4-REAL | BLOCKED | PAID+ART+HUMAN | First real learning iteration S0–S4 (after audit + consent) |  | 0 |
| ADD25-S01 | PASS |  | ADD25-S01 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S02 | PASS |  | ADD25-S02 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S03 | PASS |  | ADD25-S03 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S04 | PASS |  | ADD25-S04 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S05 | PASS |  | ADD25-S05 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 2 |
| ADD25-F01 | PASS |  | ADD25-F01 | vme.reference.probe, vme.reference.frame_index, vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| ADD25-F02 | PASS |  | ADD25-F02 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD25-F03 | PASS |  | ADD25-F03 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| ADD25-F04 | PASS |  | ADD25-F04 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD25-F05 | PASS |  | ADD25-F05 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD25-F06 | PASS |  | ADD25-F06 | vme.reference.frames | 1 |
| ADD25-F07 | PASS |  | ADD25-F07 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 7 |
| ADD25-F08 | PASS |  | ADD25-F08 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| ADD25-Q01 | PASS |  | ADD25-Q01 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD25-Q02 | PASS |  | ADD25-Q02 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD25-Q03 | PASS |  | ADD25-Q03 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD25-Q04 | PASS |  | ADD25-Q04 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD25-Q05 | PASS |  | ADD25-Q05 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD25-P01 | PASS |  | ADD25-P01 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P02 | PASS |  | ADD25-P02 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P03 | PASS |  | ADD25-P03 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P04 | PASS |  | ADD25-P04 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P05 | PASS |  | ADD25-P05 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P06 | PASS |  | ADD25-P06 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-R01 | PASS |  | ADD25-R01 | vme.loop.stages, vme.state.handoff; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| ADD25-R02 | PASS |  | ADD25-R02 | vme.loop.stages, vme.state.handoff; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| ADD25-A01 | PASS |  | ADD25-A01 | vme.loop.stages, vme.state.handoff | 1 |
| ADD25-A02 | PASS |  | ADD25-A02 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| ADD25-L0-REAL | BLOCKED | PAID | Real first-15 per-frame VLM study (PHASE L0) |  | 0 |
| ADD26-D01 | PASS |  | ADD26-D01 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD26-D02 | PASS |  | ADD26-D02 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD26-D03 | PASS |  | ADD26-D03 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 2 |
| ADD26-D04 | PASS |  | ADD26-D04 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 2 |
| ADD26-D05 | PASS |  | ADD26-D05 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-Q01 | PASS |  | ADD26-Q01 | vme.investigation.controller, vme.investigation.gaps | 2 |
| ADD26-Q02 | PASS |  | ADD26-Q02 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-Q03 | PASS |  | ADD26-Q03 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-Q04 | PASS |  | ADD26-Q04 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-Q05 | PASS |  | ADD26-Q05 | vme.loop.stages, vme.state.handoff; vme.investigation.controller, vme.investigation.gaps | 2 |
| ADD26-Q06 | PASS |  | ADD26-Q06 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-F01 | PASS |  | ADD26-F01 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD26-F02 | PASS |  | ADD26-F02 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| ADD26-F03 | PASS |  | ADD26-F03 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-F04 | PASS |  | ADD26-F04 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-S01 | PASS |  | ADD26-S01 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-S02 | PASS |  | ADD26-S02 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-P01 | PASS |  | ADD26-P01 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD26-P02 | PASS |  | ADD26-P02 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD26-P03 | PASS |  | ADD26-P03 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.investigation.controller, vme.investigation.gaps | 2 |
| ADD26-I01 | PASS |  | ADD26-I01 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-I02 | PASS |  | ADD26-I02 | vme.review.approvals, vme.review.server, vme.render.renderer; vme.loop.stages, vme.state.handoff | 2 |
| ADD26-I03 | PASS |  | ADD26-I03 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| ADD26-R01 | PASS |  | ADD26-R01 | vme.loop.stages, vme.state.handoff | 5 |
| ADD26-R02 | PASS |  | ADD26-R02 | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| ADD26-A01 | PASS |  | ADD26-A01 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.loop.stages, vme.state.handoff | 2 |
| ADD26-A02 | PASS |  | ADD26-A02 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| ADD26-S0S9 | PASS |  | ADD26-S0S9 | vme.loop.stages, vme.state.handoff | 2 |
| ADD27-1 | PASS |  | VisualModelCoverageLedger typed per schema | vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-2 | PASS |  | READY_FOR_ORIGINAL_IMAGE_TRIAL scoped/provisional | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-3 | PASS |  | Investigator finds multiple gaps; re-review after each fix | vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-4 | PASS |  | Missing face/viewpoint; colour w/o light/world link; disconnected world/camera | vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-5 | PASS |  | Joint-relation fixtures incl. pose/contact+lighting and all-NA contradiction | vme.style.coverage, vme.style.provenance, vme.skills.skill | 3 |
| ADD27-6 | PASS |  | Model-authored clause blocked at observation→skill boundary | vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-7 | PASS |  | Every appearance-affecting provider field classified (Interface II) | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-8 | PASS |  | Lost skill clause in payload fails with before/after bytes | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD27-9 | PASS |  | Free-text style via brief rejected | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-10 | PASS |  | Unexpected phenomenon → dynamic extension | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-11 | PASS |  | SOURCE_FACT/INFERRED/ENGINEERING distinctions recorded | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-12 | PASS |  | Ungoverned output appearance not credited to skill | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-13 | PASS |  | Provenance DAG lineage | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-14 | PASS |  | Crash during completeness/provenance commit recovers | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
