# Security and budget report

- **API key**: read ONLY from `RUNWARE_API_KEY` inside `vme/providers/runware.py:http_transport` at send time. It is never written,
  logged, hashed into payloads or exported. `tests/test_gateway.py::test_api_key_never_written` sets a fake key and scans every file.
  The audit ZIP and handoff exporter scan for key/Bearer patterns and refuse/omit matching files (`verify_zip`, `handoff._secret_free`).
- **Network**: disabled unless `VME_ALLOW_NETWORK=1`. No code path in this build was run with it set except tests asserting refusal.
- **Three independent barriers** for any paid/external action (`vme/providers/authorization.py`): network flag + human-issued
  `ProviderAuthorization` (exact model AIR id, task categories, USD cap, confirmation phrase, human issuer) + separate
  `source_upload_consent` listing allowed source SHA256s for any source-frame pixels. Unknown cost → `COST_UNKNOWN_STOP`.
- **Model ambiguity**: "FLUX Klein 7B" is not a confirmed Runware model; `resolve_model` refuses non-AIR names. Capability snapshots
  for `runware:400@4` (FLUX.2 [klein] 4B) and `runware:400@2` (9B) are doc-cited from the spec and marked `verified_by_probe=false`,
  `user_confirmed_model=false`, `cost_per_image_usd=null`; a paid job needs a consented probe first (`assert_paid_ready`).
- **Real external calls in this build**: Runware = 0, vision provider = 0, source-frame uploads = 0. The agent did not view or upload
  any decoded source frame; the sixth-clip witness PNGs exist only on the user's disk and are excluded from this ZIP.
- **Proposed lowest-cost real probe (needs separate approval)**: after the user confirms the exact AIR id, authorize category
  `capability_probe` with a small cap (e.g. a few cents), run ONE text-to-image original (non-source) prompt at 512×512 to
  verify accepted parameters, returned format/alpha, `cost` field and `taskUUID` reconciliation; then optionally ONE
  reference-guided edit using only original (non-source) images. Source-frame reference upload requires its own consent.
- **Vision provider**: none selected; `vme vision estimate` returns `BLOCKED_FOR_PRICE_VERIFICATION` until a provider, its image
  limits and price are verified and recorded.
