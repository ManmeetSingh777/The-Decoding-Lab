# Run instructions (independent reproduction)

Tested on: Windows 11, Python 3.14, Node 22, FFmpeg 7.x (Git Bash or PowerShell). Linux/macOS should work (POSIX paths).

```bash
cd visual-mastery-engine
python -m venv .venv && .venv/Scripts/python -m pip install -r requirements.lock     # (bin/python on POSIX)
cd render/remotion && npm ci && cd ../..                                              # Remotion 4.0.538 (downloads Chrome Headless Shell once)
.venv/Scripts/python -m pytest -q tests                                               # full suite (real-source tests skip without the MP4s)
.venv/Scripts/python -m pyflakes vme tests && .venv/Scripts/python -m mypy vme --ignore-missing-imports
```

Real local source steps (no network, no upload; the user's MP4s are required and are NOT in this ZIP):

```bash
.venv/Scripts/python -m vme sources ingest --folder ../source_clips --index-every-frame
.venv/Scripts/python -m vme survey build --all --navigation-only
.venv/Scripts/python -m vme selection sixth-locate
.venv/Scripts/python -m vme loop run --run-id SYN1 --simulate-human-fixture     # synthetic S0–S9 drill (labelled)
.venv/Scripts/python -m vme status --detailed
.venv/Scripts/python -m vme audit export --offline --out ../VME_V13_IMPLEMENTATION_AUDIT.zip
```

`reference_impl` suites: `cd Visual_Mastery_Engine_Build_Spec_v1_3/reference_impl && python -m unittest -v` (and `reference_impl_v13`).
Observed in this build: pytest exit=0; see audit/logs/*.txt and TEST_RESULTS.json.
