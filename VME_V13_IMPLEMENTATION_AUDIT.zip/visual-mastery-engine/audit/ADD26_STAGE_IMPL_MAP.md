# S0–S9 stage implementation map

| Stage | Handler | Real consumers called | Persisted outputs | Next consumer | Tests |
|---|---|---|---|---|---|
| S0 | `vme.loop.stages:LoopRunner._s0` | `vme.selection.first15:propose_selection, vme.selection.sixth:locate_sixth_intro` | SelectedSequenceManifest, SixthIntroLocatorResult | S1 (frame packets) | tests/test_selection_sixth.py, tests/test_loop_handoff.py |
| S1 | `LoopRunner._s1` | `vme.vision.runner:plan_packets/PacketRunner.run, vme.investigation.evidence:build_event_graph` | SemanticPacketCheckpoint, frame_vision rows, CrossFrameEventGraph | S2 | tests/test_vision_ledger.py |
| S2 | `LoopRunner._s2` | `vme.investigation.gaps:rank_gaps/select_cluster, vme.investigation.controller:LoopController` | GapRanking, ActiveArtProblem, NextQuestion, AnswerEffect | S3 (decision_writer) | tests/test_questions.py |
| S3 | `LoopRunner._s3/_write_decision` | `vme.style.decisions:witness_to_decision` | ConditionalVisualDecision | S4 (decision_overrides) | tests/test_style_decisions.py |
| S4 | `LoopRunner._s4` | `vme.skills.skill:write_skill/freeze_skill, vme.style.coverage:review_visual_model_completeness` | skill folder + FROZEN.json, CoverageReview | S5 (pinned skill hash) | tests/test_completeness_provenance.py |
| S5 | `LoopRunner._s5` | `vme.compiler.compiler:StyleProgramCompiler.compile, vme.providers.gateway:StyleImageGateway.submit` | CompiledImageJob, GeneratedRaster | S6 (review images) | tests/test_compiler_authority.py, tests/test_gateway.py |
| S6 | `LoopRunner._s6` | `vme.review.approvals:GateKeeper.submit_art_verdict` | ArtApproval, VisualGateState | S7 | tests/test_gates_render.py |
| S7 | `LoopRunner._s7` | `vme.artwork.character:character_construction_plan, vme.artwork.assets:verify_pack, GateKeeper.submit_asset_verdict` | CharacterConstructionPlan, AssetReport, AssetApproval | S8 | tests/test_assets_character.py |
| S8 | `LoopRunner._s8` | `vme.render.renderer:render_video (GateKeeper.authorize_render first)` | RenderReport (MP4 + motion evidence) | S9 | tests/test_gates_render.py |
| S9 | `LoopRunner._s9` | `vme.experiments.experiments:HoldoutRegistry, LoopController.observe_new_output/step_question` | TransferRecord, new NextQuestion | next S2/S3/S4 per routing | tests/test_experiments_diagnosis.py, tests/test_loop_handoff.py |

Every transition is persisted as a `LoopTransition` record (store), crash points `loop_after_S<n>`; resume skips COMPLETED stages, re-attempts STOPPED ones.
