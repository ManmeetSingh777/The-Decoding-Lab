# Read this first — Independent VME repair package

**Status: BLOCKED FOR REAL 15+1 ANALYSIS.** This ZIP is an independent diagnostic plus
a small proven patch, not a certification that the whole visual-learning engine is finished.

1. Keep your existing Claude Code repository and earlier ZIP untouched.
2. Download this package and place it somewhere under `G:\The Decoding Lab\`.
3. In the **same Claude Code implementation chat**, attach or point Claude to this ZIP.
4. Paste the full `00_PASTE_INTO_CLAUDE_CODE.txt`.
5. Let it perform corrections and export a **new** evidence ZIP. Do **not** grant source
   uploads, API authorizations or paid generation while the engineering audit remains open.
6. Return the **new** evidence ZIP here for another independent code-path audit. The
   six-minute or other actual MP4 is a separate input for a later calibrated artistic
   investigation trial; this ZIP does not contain that video.

### Contents

- `01_INDEPENDENT_FORENSIC_AUDIT.md`: confirmed code defects, independently inspected
  risks, production capabilities absent, source-first character-art standard, gates.
- `INDEPENDENT_REDTEAM.py`: 5 adversarial standard-library tests. All fail on the original
  snapshot; all pass in the *limited* corrected copy. No network needed.
- `corrected_modules/vme/...`: only three **example corrected files** for these five
  direct bugs. Claude must compare the live files and **merge carefully** rather than
  replace unrelated work. Unresolved F06–F18 are not magically fixed.
- `00_PASTE_INTO_CLAUDE_CODE.txt`: executable integration and verification instructions.

### Independent evidence summary

Original ZIP hash:
`0e49e93bfc9f2f696fc816957406b46d87f15af58e73467851a8f7fe06ad939c`

Original: 4 test failures, 1 error. Isolated corrected-copy retest: 5 passed, 0 failed.
`python3 -m compileall -q vme`: exit 0. Tests were written independently after reading
source, not copied from Claude's positive fixtures. The original ~90-minute suite was
not rerun here (pytest unavailable in this runtime); the next implementation audit must
run it against final, merged code.

Do not treat model tokens/API receipts as evidence that an AI actually understood art.
That requires real source frames, output comparisons and independent review.
