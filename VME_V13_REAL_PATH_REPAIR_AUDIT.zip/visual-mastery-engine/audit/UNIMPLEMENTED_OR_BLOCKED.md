# Unimplemented or blocked

Requirement totals (from executed tests): {"ENGINEERING_FIXTURE_PASS": 179, "BLOCKED_AUTHORIZATION": 6, "ART_QUALITY_UNPROVEN": 33, "REAL_PATH_WIRED_UNTESTED": 8, "FAIL": 6, "NOT_IMPLEMENTED": 3}

## FAIL
- A65: Idempotent/reconciled paid requests — ['tests/test_gateway.py::test_gateway_unreconcilable_pending_is_unknown_billing', 'tests/test_real_path.py::test_hard_kill_mid_packet_reconciles_batches', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_inputs_ready]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_inflight_commit]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_submit_before_save]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_raw_response]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[mid_semantic_commit]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_semantic_commit]', 'tests/test_vision_ledger.py::test_unqueryable_pending_task_is_unknown_billing_not_resubmitted']
- B06: Kill around paid request; no duplicate — ['tests/test_gateway.py::test_gateway_kill_after_send_reconciles_without_rebilling', 'tests/test_real_path.py::test_hard_kill_mid_packet_reconciles_batches', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_inputs_ready]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_inflight_commit]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_submit_before_save]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_raw_response]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[mid_semantic_commit]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_semantic_commit]', 'tests/test_vision_ledger.py::test_unqueryable_pending_task_is_unknown_billing_not_resubmitted']
- C14: Style-exclusive prompt authority — ['tests/test_compiler_authority.py::test_runtime_style_append_and_raw_prompt_refused', 'tests/test_compiler_authority.py::test_static_scan_only_compiler_builds_positive_prompt_and_only_gateway_sends']
- ADD24-D4-1: Kill mid-frame sequence; fresh process resumes exact next PTS — ['tests/test_real_path.py::test_hard_kill_mid_packet_reconciles_batches', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_inputs_ready]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_inflight_commit]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_submit_before_save]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_raw_response]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[mid_semantic_commit]', 'tests/test_vision_ledger.py::test_hard_kill_at_every_boundary_then_resume_new_process[after_semantic_commit]']
- ADD24-D4-2: Kill after provider submission; reconcile, no double charge — ['tests/test_gateway.py::test_gateway_kill_after_send_reconciles_without_rebilling', 'tests/test_real_path.py::test_hard_kill_mid_packet_reconciles_batches']
- ADD26-A01: ADD26-A01 — ['tests/test_compiler_authority.py::test_static_scan_only_compiler_builds_positive_prompt_and_only_gateway_sends', 'tests/test_loop_handoff.py::test_e2e_all_stages_real_consumers']

## NOT_IMPLEMENTED (no passing REAL-path test)
- AUDIT-P0-1: REAL loop connected S0–S9 (no unconditional blocks; providers injected)
- AUDIT-P0-2: Concrete vision provider integration with response conversion and reconciliation
- AUDIT-P0-4: Multi-gap controller with completeness recomputation over the scoped scene

## Wired but unproven (REAL_PATH_WIRED_UNTESTED / BLOCKED_AUTHORIZATION / ART_QUALITY_UNPROVEN)
- A04 [BLOCKED_AUTHORIZATION; needs PAID]: Provider capability call returns real file + cost
- A08 [ART_QUALITY_UNPROVEN; needs ART]: Several ranked gaps with source+original witnesses
- A10 [BLOCKED_AUTHORIZATION; needs PAID]: Specific observation with full context and producing decision
- A11 [REAL_PATH_WIRED_UNTESTED; needs a real provider run]: Skill conversion: executable recipe consumed by producer
- A12 [ART_QUALITY_UNPROVEN; needs PAID+ART]: Causality: disable/enable method changes intended output
- A13 [ART_QUALITY_UNPROVEN; needs ART]: Multi-change attribution via toggles
- A15 [ART_QUALITY_UNPROVEN; needs PAID+ART]: Controlled anchor A/B without confounds
- A16 [ART_QUALITY_UNPROVEN; needs PAID+ART]: Rotating development brief, no manual rescue
- A17 [ART_QUALITY_UNPROVEN; needs PAID+ART]: Blind transfer after freeze
- A18 [ART_QUALITY_UNPROVEN; needs HUMAN+ART]: Human review sees stills/MP4/gaps; feedback saved
- A21 [ART_QUALITY_UNPROVEN; needs ART]: Image-to-motion identity consistency
- A24 [ART_QUALITY_UNPROVEN; needs PAID+ART+HUMAN]: Integrated approved iteration with 12–20 s MP4
- A25 [ART_QUALITY_UNPROVEN; needs PAID+ART+HUMAN]: 20–30 s multi-shot film under frozen skills
- A28 [BLOCKED_AUTHORIZATION; needs PAID]: All-frame VLM estimate + gated segmented execution
- A32 [ART_QUALITY_UNPROVEN; needs ART]: Originality vs clone discrimination on outputs
- A37 [ART_QUALITY_UNPROVEN; needs ART]: Visual prompt-output review on real images
- A38 [ART_QUALITY_UNPROVEN; needs HUMAN+ART]: Canonical character human verdict tied to hashes
- A39 [ART_QUALITY_UNPROVEN; needs ART]: Coherent multi-view/face identity
- A45 [ART_QUALITY_UNPROVEN; needs ART]: First cycles emphasise characters with real art
- A52 [REAL_PATH_WIRED_UNTESTED; needs a real provider run]: Design plan + recipe exist before provider call
- A58 [ART_QUALITY_UNPROVEN; needs ART]: Character generated first as whole canonical art
- A59 [ART_QUALITY_UNPROVEN; needs ART]: Canonical-conditioned face/pose/hand states
- A61 [REAL_PATH_WIRED_UNTESTED; needs a real provider run]: Every frame decoded; per-frame VLM truthfully separate
- A67 [ART_QUALITY_UNPROVEN; needs ART+HUMAN]: User review on full-size art before layers/motion
- A68 [ART_QUALITY_UNPROVEN; needs ART]: reference_impl tests pass; app pinned-skill→real request→real image
- B28 [ART_QUALITY_UNPROVEN; needs ART]: Alternate view identity drift → route reexamined
- B29 [ART_QUALITY_UNPROVEN; needs ART]: Weak actor art → no render
- B32 [ART_QUALITY_UNPROVEN; needs ART]: One-scene improvement not transferable
- B33 [ART_QUALITY_UNPROVEN; needs PAID+ART]: Skill can't produce visual difference reported
- B34 [ART_QUALITY_UNPROVEN; needs ART]: Rich still but flat motion → no pan-only proof
- C03 [REAL_PATH_WIRED_UNTESTED; needs a real provider run]: True every-frame VLM availability
- C12 [REAL_PATH_WIRED_UNTESTED; needs a real provider run]: Manufacture plan exists
- C13 [REAL_PATH_WIRED_UNTESTED; needs a real provider run]: Skill is a working producer
- C17 [BLOCKED_AUTHORIZATION; needs PAID]: Correct actual provider (live catalog/probe)
- C18 [BLOCKED_AUTHORIZATION; needs PAID]: Real image bytes
- C19 [ART_QUALITY_UNPROVEN; needs ART]: Artwork appealing at construction
- C20 [ART_QUALITY_UNPROVEN; needs ART]: Character identity across poses
- C21 [ART_QUALITY_UNPROVEN; needs ART]: Face/expression language
- C27 [ART_QUALITY_UNPROVEN; needs ART]: Simultaneous world activity
- C28 [ART_QUALITY_UNPROVEN; needs ART]: Perspective/attention continuity
- C32 [ART_QUALITY_UNPROVEN; needs PAID+ART]: Reliable transfer
- ADD24-S0S4-REAL [ART_QUALITY_UNPROVEN; needs PAID+ART+HUMAN]: First real learning iteration S0–S4 (after audit + consent)
- ADD25-L0-REAL [BLOCKED_AUTHORIZATION; needs PAID]: Real first-15 per-frame VLM study (PHASE L0)
- ADD26-S0S9 [REAL_PATH_WIRED_UNTESTED; needs a real provider run]: ADD26-S0S9
- AUDIT-P0-3 [ART_QUALITY_UNPROVEN; needs ART]: Evidence→decision→skill authoring from persisted witnesses (no lexical proof)
- AUDIT-P0-5 [REAL_PATH_WIRED_UNTESTED; needs HUMAN]: Source identities quarantined until user confirmation; resolution reported
- AUDIT-P0-6 [ART_QUALITY_UNPROVEN; needs PAID+ART+HUMAN]: Runware + character asset creation + art/asset/video human review paths

## Known engineering limits (truthful)
- Vision provider: Claude Messages Batches adapter (`vme/vision/claude_adapter.py`, model `claude-opus-5-5`, official SDK) is implemented
  and exercised ONLY through a SIMULATED client. The 20-images-per-request limit is a planning assumption and the price comes from a cached
  table — both UNVERIFIED until a consented Models-API discovery call.
- REAL first-15 selection needs the five base films CONFIRMED by the user (currently quarantined: titles differ from the contract),
  then authorized VLM rationales. The sixth clip role is USER_CONFIRMED (2026-11-15); its volcano/logo boundaries are still unlocked.
- Character layers: no segmentation/inpainting capability is verified, so the REAL path uses an explicit WHOLE_STATE_SWAP (whole
  identity-conditioned drawings swapped by the renderer) instead of pretend layers. Expression states have no decision condition yet.
- `op.clean_plate` / `op.layer_extract` real implementations depend on provider edit/mask capability; the offline fixture uses a local
  fill on fixture rasters (wiring only). Real segmentation/matting model not chosen.
- Motion evidence is block-translation based: motion over textureless regions is not counted either way (documented limitation).
- Interface-I lexical grounding is a crude executable derivation check, not semantic proof that a clause follows from an observation.
- Artistic quality, identity consistency, transfer and video quality are UNEVALUATED (no real art exists).
