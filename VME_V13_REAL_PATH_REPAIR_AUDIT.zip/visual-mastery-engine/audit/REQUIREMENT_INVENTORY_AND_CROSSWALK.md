# Requirement inventory and crosswalk

Generated 2026-11-15T00:52:46+00:00 from executed tests.

## Original approved 13 parts → modules

- **P01 Six connected responsibilities** → `vme.reference`, `vme.investigation.gaps`, `vme.investigation.controller`, `vme.skills`, `vme.providers.gateway`, `vme.review`
- **P02 High-impact gap identification** → `vme.investigation.gaps:rank_gaps/select_cluster`
- **P03 Question engine** → `vme.investigation.controller:derive_next_question`
- **P04 Working skill conversion** → `vme.style.decisions`, `vme.skills.skill`, `vme.compiler.compiler`
- **P05 Sequential lead + bounded parallel** → `vme.investigation.controller:LoopController`, `vme.reference.ingest:index_all (bounded threads)`
- **P06 Iteration protocol with user review gates** → `vme.loop.stages`, `vme.review.approvals`
- **P07 Fast learning, persistence** → `vme.state.store`, `vme.state.handoff`, `vme.vision.runner`
- **P08 Visual first, animation-aware** → `vme.artwork.character:derive_animation_demand`, `vme.render.renderer`
- **P09 No overfitting (anchor/rotating/unseen)** → `vme.experiments.experiments:HoldoutRegistry`
- **P10 Concrete engineering modules + CLI** → `vme.cli`
- **P11 First real learning cycle** → `vme.loop.stages (REAL mode stops at consent)`
- **P12 Failure diagnosis and stop policies** → `vme.diagnose.diagnose`, `vme.util.Blocked`
- **P13 Success gates (art/transfer/animation/integrated)** → `vme.review.approvals`, `vme.experiments.experiments:transfer_status`

## Every requirement ID

| ID | Status | Needs | Requirement | Module(s) | Tests |
|---|---|---|---|---|---|
| A01 | ENGINEERING_FIXTURE_PASS |  | Fresh repo; no prior AnimationLab inputs | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 1 |
| A02 | ENGINEERING_FIXTURE_PASS |  | Ingest sources: ffprobe, SHA256, decode | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| A03 | ENGINEERING_FIXTURE_PASS |  | Targeted retrieval + native crops + adjacent sequence | vme.reference.frames; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| A04 | BLOCKED_AUTHORIZATION | PAID | Provider capability call returns real file + cost | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ? | 2 |
| A05 | ENGINEERING_FIXTURE_PASS |  | No paid call without budget; no upload without consent | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| A06 | ENGINEERING_FIXTURE_PASS |  | Scene/asset schema validation | vme.review.approvals, vme.review.server, vme.render.renderer; vme.audit.contracts | 2 |
| A07 | ENGINEERING_FIXTURE_PASS |  | Renderer refuses before approvals; ffprobe-verified MP4 after | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A08 | ART_QUALITY_UNPROVEN | ART | Several ranked gaps with source+original witnesses | vme.investigation.controller, vme.investigation.gaps | 1 |
| A09 | ENGINEERING_FIXTURE_PASS |  | Connected cluster with dependencies and exclusions | vme.investigation.controller, vme.investigation.gaps | 1 |
| A10 | BLOCKED_AUTHORIZATION | PAID | Specific observation with full context and producing decision | vme.investigation.controller, vme.investigation.gaps; ? | 2 |
| A11 | REAL_PATH_WIRED_UNTESTED |  | Skill conversion: executable recipe consumed by producer | vme.experiments.experiments, vme.diagnose.diagnose; ? | 2 |
| A12 | ART_QUALITY_UNPROVEN | PAID+ART | Causality: disable/enable method changes intended output | vme.experiments.experiments, vme.diagnose.diagnose | 2 |
| A13 | ART_QUALITY_UNPROVEN | ART | Multi-change attribution via toggles | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A14 | ENGINEERING_FIXTURE_PASS |  | Multiple-root diagnosis separates causes | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A15 | ART_QUALITY_UNPROVEN | PAID+ART | Controlled anchor A/B without confounds | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A16 | ART_QUALITY_UNPROVEN | PAID+ART | Rotating development brief, no manual rescue | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A17 | ART_QUALITY_UNPROVEN | PAID+ART | Blind transfer after freeze | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A18 | ART_QUALITY_UNPROVEN | HUMAN+ART | Human review sees stills/MP4/gaps; feedback saved | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A19 | ENGINEERING_FIXTURE_PASS |  | Kill/restart after partial provider request; no duplicate bill | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.loop.stages, vme.state.handoff; ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 9 |
| A20 | ENGINEERING_FIXTURE_PASS |  | Per-run cost accounting, unknown costs explicit | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 1 |
| A21 | ART_QUALITY_UNPROVEN | ART | Image-to-motion identity consistency | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A22 | ENGINEERING_FIXTURE_PASS |  | Unsupported capability → named stop | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 5 |
| A23 | ENGINEERING_FIXTURE_PASS |  | Separate PASS/FAIL/UNTESTED statuses | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A24 | ART_QUALITY_UNPROVEN | PAID+ART+HUMAN | Integrated approved iteration with 12–20 s MP4 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A25 | ART_QUALITY_UNPROVEN | PAID+ART+HUMAN | 20–30 s multi-shot film under frozen skills | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A26 | ENGINEERING_FIXTURE_PASS |  | Every decoded frame + PTS indexed; VFR kept | vme.audit.contracts; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 4 |
| A27 | ENGINEERING_FIXTURE_PASS |  | Coverage ledger separates indexed/sent/verified/native | vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| A28 | BLOCKED_AUTHORIZATION | PAID | All-frame VLM estimate + gated segmented execution | ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 3 |
| A29 | ENGINEERING_FIXTURE_PASS |  | Corrupt/skipped/VFR/last-frame injection caught | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 3 |
| A30 | ENGINEERING_FIXTURE_PASS |  | Style mechanism vs source fact | vme.style.decisions, vme.investigation.evidence | 1 |
| A31 | ENGINEERING_FIXTURE_PASS |  | Cross-subject conditions and counterexamples | vme.style.decisions, vme.investigation.evidence | 1 |
| A32 | ART_QUALITY_UNPROVEN | ART | Originality vs clone discrimination on outputs | vme.style.decisions, vme.investigation.evidence | 1 |
| A33 | ENGINEERING_FIXTURE_PASS |  | Every style clause traces to skill; content to brief | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| A34 | ENGINEERING_FIXTURE_PASS |  | Clause coverage/contradiction; nothing silently dropped | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A35 | ENGINEERING_FIXTURE_PASS |  | Prompt length/reference count/dimension validation | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| A36 | ENGINEERING_FIXTURE_PASS |  | Skill change → request change (and output where feasible) | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; ? | 2 |
| A37 | ART_QUALITY_UNPROVEN | ART | Visual prompt-output review on real images | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A38 | ART_QUALITY_UNPROVEN | HUMAN+ART | Canonical character human verdict tied to hashes | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A39 | ART_QUALITY_UNPROVEN | ART | Coherent multi-view/face identity | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A40 | ENGINEERING_FIXTURE_PASS |  | Limb/hand/prop/ground relationship validation | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 13 |
| A41 | ENGINEERING_FIXTURE_PASS |  | Layer/mask/clean-plate recomposition | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 15 |
| A42 | ENGINEERING_FIXTURE_PASS |  | Artwork approval gate; rejected art cannot render | vme.review.approvals, vme.review.server, vme.render.renderer | 3 |
| A43 | ENGINEERING_FIXTURE_PASS |  | Asset pack approval gate | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| A44 | ENGINEERING_FIXTURE_PASS |  | Reapproval after replacement | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| A45 | ART_QUALITY_UNPROVEN | ART | First cycles emphasise characters with real art | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A46 | ENGINEERING_FIXTURE_PASS |  | Independent multi-failure diagnosis | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| A47 | ENGINEERING_FIXTURE_PASS |  | Resume keeps approvals/pending reviews/idempotency | vme.review.approvals, vme.review.server, vme.render.renderer; vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.loop.stages, vme.state.handoff; vme.audit.contracts | 5 |
| A48 | ENGINEERING_FIXTURE_PASS |  | Separate claim statuses; tests ≠ mastery | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A49 | ENGINEERING_FIXTURE_PASS |  | Scene facts separated before skill writing | vme.style.decisions, vme.investigation.evidence | 1 |
| A50 | ENGINEERING_FIXTURE_PASS |  | Question ladder does not stop on adjectives | vme.style.decisions, vme.investigation.evidence | 1 |
| A51 | ENGINEERING_FIXTURE_PASS |  | Decisions carry applicability/variants/exclusions/freedoms | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.style.decisions, vme.investigation.evidence | 2 |
| A52 | REAL_PATH_WIRED_UNTESTED |  | Design plan + recipe exist before provider call | ?; vme.style.decisions, vme.investigation.evidence | 2 |
| A53 | ENGINEERING_FIXTURE_PASS |  | Runtime style insertion cannot change request | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A54 | ENGINEERING_FIXTURE_PASS |  | Missing essential decision blocks; no default style | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| A55 | ENGINEERING_FIXTURE_PASS |  | Stage-specific operations (canonical vs pose vs grip) | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| A56 | ENGINEERING_FIXTURE_PASS |  | Style-like language in brief separated/rejected | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; ? | 2 |
| A57 | ENGINEERING_FIXTURE_PASS |  | Reference slots by skill rules and capability; identity bytes | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; ? | 3 |
| A58 | ART_QUALITY_UNPROVEN | ART | Character generated first as whole canonical art | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A59 | ART_QUALITY_UNPROVEN | ART | Canonical-conditioned face/pose/hand states | vme.artwork.raster, vme.artwork.assets, vme.artwork.character; vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; ? | 4 |
| A60 | ENGINEERING_FIXTURE_PASS |  | AnimationDemandPlan before art generation | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| A61 | REAL_PATH_WIRED_UNTESTED |  | Every frame decoded; per-frame VLM truthfully separate | ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 10 |
| A62 | ENGINEERING_FIXTURE_PASS |  | Per-frame semantic entries; summary rejected | ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 8 |
| A63 | ENGINEERING_FIXTURE_PASS |  | Boundary state across packets | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| A64 | ENGINEERING_FIXTURE_PASS |  | Semantic replay across new session | ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 9 |
| A65 | FAIL |  | Idempotent/reconciled paid requests | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 9 |
| A66 | ENGINEERING_FIXTURE_PASS |  | Two-film-first vs all-five accurate reporting | vme.reference.probe, vme.reference.frame_index, vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| A67 | ART_QUALITY_UNPROVEN | ART+HUMAN | User review on full-size art before layers/motion | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| A68 | ART_QUALITY_UNPROVEN | ART | reference_impl tests pass; app pinned-skill→real request→real image | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B01 | ENGINEERING_FIXTURE_PASS |  | Only allowed MP4s in provenance | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 1 |
| B02 | ENGINEERING_FIXTURE_PASS |  | Frame index+PTS hash exact | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 1 |
| B03 | ENGINEERING_FIXTURE_PASS |  | Index all, VLM exactly zero | vme.reference.frames; vme.reference.probe, vme.reference.frame_index, vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 3 |
| B04 | ENGINEERING_FIXTURE_PASS |  | Missing frame in vision result → no commit | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| B05 | ENGINEERING_FIXTURE_PASS |  | Input hash mismatch → quarantine | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| B06 | FAIL |  | Kill around paid request; no duplicate | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 9 |
| B07 | ENGINEERING_FIXTURE_PASS |  | Kill after response before commit | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| B08 | ENGINEERING_FIXTURE_PASS |  | New session from CONTINUE_HERE+DB | vme.loop.stages, vme.state.handoff; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| B09 | ENGINEERING_FIXTURE_PASS |  | Vague 'polished' → targeted cause | vme.investigation.controller, vme.investigation.gaps; vme.style.decisions, vme.investigation.evidence | 2 |
| B10 | ENGINEERING_FIXTURE_PASS |  | Source noun in decision demoted | vme.style.decisions, vme.investigation.evidence | 1 |
| B11 | ENGINEERING_FIXTURE_PASS |  | Single source stays conditional | vme.style.decisions, vme.investigation.evidence | 1 |
| B12 | ENGINEERING_FIXTURE_PASS |  | Connected world/character/colour cluster | vme.investigation.controller, vme.investigation.gaps | 1 |
| B13 | ENGINEERING_FIXTURE_PASS |  | Question lacking producing unknown parked | vme.investigation.controller, vme.investigation.gaps; ? | 2 |
| B14 | ENGINEERING_FIXTURE_PASS |  | No exceptions/adaptations → not frozen | vme.style.decisions, vme.investigation.evidence | 1 |
| B15 | ENGINEERING_FIXTURE_PASS |  | No operation → research-only | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.style.decisions, vme.investigation.evidence | 2 |
| B16 | ENGINEERING_FIXTURE_PASS |  | SKILL.md-only refused | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B17 | ENGINEERING_FIXTURE_PASS |  | Selected clause change changes prompt | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; ? | 2 |
| B18 | ENGINEERING_FIXTURE_PASS |  | Non-selected prose change no effect | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B19 | ENGINEERING_FIXTURE_PASS |  | Raw positivePrompt refused | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B20 | ENGINEERING_FIXTURE_PASS |  | Style rewrite in brief → ticket/block | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; ? | 2 |
| B21 | ENGINEERING_FIXTURE_PASS |  | Pose edit without identity refused | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B22 | ENGINEERING_FIXTURE_PASS |  | Reference overflow staged or blocked | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| B23 | ENGINEERING_FIXTURE_PASS |  | '7B' without verified model refused | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ? | 2 |
| B24 | ENGINEERING_FIXTURE_PASS |  | No consent → network refused | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 3 |
| B25 | ENGINEERING_FIXTURE_PASS |  | Opaque PNG never transparent | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B26 | ENGINEERING_FIXTURE_PASS |  | Layer dimension/origin mismatch caught | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 14 |
| B27 | ENGINEERING_FIXTURE_PASS |  | Hand/prop whole pose before layers | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B28 | ART_QUALITY_UNPROVEN | ART | Alternate view identity drift → route reexamined | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B29 | ART_QUALITY_UNPROVEN | ART | Weak actor art → no render | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| B30 | ENGINEERING_FIXTURE_PASS |  | Approved hash change invalidates | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| B31 | ENGINEERING_FIXTURE_PASS |  | Multiple failures → separate trails | vme.experiments.experiments, vme.diagnose.diagnose; vme.investigation.controller, vme.investigation.gaps | 2 |
| B32 | ART_QUALITY_UNPROVEN | ART | One-scene improvement not transferable | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| B33 | ART_QUALITY_UNPROVEN | PAID+ART | Skill can't produce visual difference reported | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| B34 | ART_QUALITY_UNPROVEN | ART | Rich still but flat motion → no pan-only proof | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| B35 | ENGINEERING_FIXTURE_PASS |  | Audit ZIP contents | vme.loop.stages, vme.state.handoff | 1 |
| B36 | ENGINEERING_FIXTURE_PASS |  | Claims map to function/test/evidence | vme.audit.contracts | 1 |
| C01 | ENGINEERING_FIXTURE_PASS |  | Fresh source allowlist | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| C02 | ENGINEERING_FIXTURE_PASS |  | Accurate film/time/frames | vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| C03 | REAL_PATH_WIRED_UNTESTED |  | True every-frame VLM availability | vme.reference.frames; ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 4 |
| C04 | ENGINEERING_FIXTURE_PASS |  | Native-detail inspection | vme.reference.frames; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 3 |
| C05 | ENGINEERING_FIXTURE_PASS |  | Scene+temporal understanding (boundary, adjacency) | ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| C06 | ENGINEERING_FIXTURE_PASS |  | High-impact question selection | vme.investigation.controller, vme.investigation.gaps | 1 |
| C07 | ENGINEERING_FIXTURE_PASS |  | Deep observation, not slogans | vme.investigation.controller, vme.investigation.gaps; vme.style.decisions, vme.investigation.evidence | 2 |
| C08 | ENGINEERING_FIXTURE_PASS |  | Self-correcting questions | vme.investigation.controller, vme.investigation.gaps; ? | 2 |
| C09 | ENGINEERING_FIXTURE_PASS |  | Style independent of source subject | vme.style.decisions, vme.investigation.evidence | 1 |
| C10 | ENGINEERING_FIXTURE_PASS |  | Style isn't just recurrence | vme.style.decisions, vme.investigation.evidence | 1 |
| C11 | ENGINEERING_FIXTURE_PASS |  | Integration across disciplines | vme.style.decisions, vme.investigation.evidence | 1 |
| C12 | REAL_PATH_WIRED_UNTESTED |  | Manufacture plan exists | ?; vme.style.decisions, vme.investigation.evidence | 2 |
| C13 | REAL_PATH_WIRED_UNTESTED |  | Skill is a working producer | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.loop.stages, vme.state.handoff; ? | 4 |
| C14 | FAIL |  | Style-exclusive prompt authority | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| C15 | ENGINEERING_FIXTURE_PASS |  | New content vs learned style | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| C16 | ENGINEERING_FIXTURE_PASS |  | Specific prompts without bloat | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 2 |
| C17 | BLOCKED_AUTHORIZATION | PAID | Correct actual provider (live catalog/probe) | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ? | 3 |
| C18 | BLOCKED_AUTHORIZATION | PAID | Real image bytes | vme.artwork.raster, vme.artwork.assets, vme.artwork.character; vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ? | 8 |
| C19 | ART_QUALITY_UNPROVEN | ART | Artwork appealing at construction | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| C20 | ART_QUALITY_UNPROVEN | ART | Character identity across poses | vme.artwork.raster, vme.artwork.assets, vme.artwork.character; ? | 3 |
| C21 | ART_QUALITY_UNPROVEN | ART | Face/expression language | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| C22 | ENGINEERING_FIXTURE_PASS |  | Limb/hand/contact logic | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 14 |
| C23 | ENGINEERING_FIXTURE_PASS |  | Part & layer usability | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 15 |
| C24 | ENGINEERING_FIXTURE_PASS |  | Coordinate handoff | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 15 |
| C25 | ENGINEERING_FIXTURE_PASS |  | Correct render tool | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C26 | ENGINEERING_FIXTURE_PASS |  | Motion-aware art; no pan disguise | vme.review.approvals, vme.review.server, vme.render.renderer | 2 |
| C27 | ART_QUALITY_UNPROVEN | ART | Simultaneous world activity | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C28 | ART_QUALITY_UNPROVEN | ART | Perspective/attention continuity | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C29 | ENGINEERING_FIXTURE_PASS |  | Source→skill causality | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.experiments.experiments, vme.diagnose.diagnose; ? | 3 |
| C30 | ENGINEERING_FIXTURE_PASS |  | Multiple connected gaps | vme.investigation.controller, vme.investigation.gaps | 1 |
| C31 | ENGINEERING_FIXTURE_PASS |  | Root-cause diagnosis | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| C32 | ART_QUALITY_UNPROVEN | PAID+ART | Reliable transfer | vme.experiments.experiments, vme.diagnose.diagnose | 1 |
| C33 | ENGINEERING_FIXTURE_PASS |  | User approval before motion | vme.review.approvals, vme.review.server, vme.render.renderer | 4 |
| C34 | ENGINEERING_FIXTURE_PASS |  | Complete evidence+budget | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities | 3 |
| C35 | ENGINEERING_FIXTURE_PASS |  | Crash and timeout resume | vme.loop.stages, vme.state.handoff; ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 13 |
| C36 | ENGINEERING_FIXTURE_PASS |  | User can audit build | vme.review.approvals, vme.review.server, vme.render.renderer; vme.audit.contracts | 5 |
| C37 | ENGINEERING_FIXTURE_PASS |  | Honest qualification | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| C38 | ENGINEERING_FIXTURE_PASS |  | No unauthorized source upload | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 4 |
| ADD24-E1 | ENGINEERING_FIXTURE_PASS |  | Five-film mapping + cross-film sequence selection as code contracts | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD24-E2 | ENGINEERING_FIXTURE_PASS |  | Character witness grouping, question traces, skill clauses, C1→C7 on synthetic fixtures | vme.loop.stages, vme.state.handoff | 2 |
| ADD24-E3 | ENGINEERING_FIXTURE_PASS |  | Persistent semantic work units + export/import cold start | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-B1 | ENGINEERING_FIXTURE_PASS |  | Cross-actor witness groups (a)–(f) | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| ADD24-B2 | ENGINEERING_FIXTURE_PASS |  | Ten question families with required record fields | vme.artwork.raster, vme.artwork.assets, vme.artwork.character | 1 |
| ADD24-D1 | ENGINEERING_FIXTURE_PASS |  | Disk-owned workspace layout | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D2 | ENGINEERING_FIXTURE_PASS |  | Atomic persistence at reasoning boundaries | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D3 | ENGINEERING_FIXTURE_PASS |  | status/checkpoint/export-handoff/import-handoff/resume commands | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D4-1 | FAIL |  | Kill mid-frame sequence; fresh process resumes exact next PTS | ?; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 7 |
| ADD24-D4-2 | FAIL |  | Kill after provider submission; reconcile, no double charge | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; ? | 2 |
| ADD24-D4-3 | ENGINEERING_FIXTURE_PASS |  | Kill between observation and skill conversion | vme.loop.stages, vme.state.handoff; ? | 6 |
| ADD24-D4-4 | ENGINEERING_FIXTURE_PASS |  | Kill during character pose generation | vme.loop.stages, vme.state.handoff | 6 |
| ADD24-D4-5 | ENGINEERING_FIXTURE_PASS |  | Corrupt/drop asset or MP4 → import refuses complete | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D4-6 | ENGINEERING_FIXTURE_PASS |  | Switch environment via handoff ZIP; reproduce compiled prompt bytes | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-D4-7 | ENGINEERING_FIXTURE_PASS |  | Review approval/rejection survives import | vme.loop.stages, vme.state.handoff | 1 |
| ADD24-S0S4-REAL | ART_QUALITY_UNPROVEN | PAID+ART+HUMAN | First real learning iteration S0–S4 (after audit + consent) | ? | 1 |
| ADD25-S01 | ENGINEERING_FIXTURE_PASS |  | ADD25-S01 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S02 | ENGINEERING_FIXTURE_PASS |  | ADD25-S02 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S03 | ENGINEERING_FIXTURE_PASS |  | ADD25-S03 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S04 | ENGINEERING_FIXTURE_PASS |  | ADD25-S04 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD25-S05 | ENGINEERING_FIXTURE_PASS |  | ADD25-S05 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 2 |
| ADD25-F01 | ENGINEERING_FIXTURE_PASS |  | ADD25-F01 | vme.reference.probe, vme.reference.frame_index, vme.reference.frames; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| ADD25-F02 | ENGINEERING_FIXTURE_PASS |  | ADD25-F02 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD25-F03 | ENGINEERING_FIXTURE_PASS |  | ADD25-F03 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| ADD25-F04 | ENGINEERING_FIXTURE_PASS |  | ADD25-F04 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD25-F05 | ENGINEERING_FIXTURE_PASS |  | ADD25-F05 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD25-F06 | ENGINEERING_FIXTURE_PASS |  | ADD25-F06 | vme.reference.frames | 1 |
| ADD25-F07 | ENGINEERING_FIXTURE_PASS |  | ADD25-F07 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 7 |
| ADD25-F08 | ENGINEERING_FIXTURE_PASS |  | ADD25-F08 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| ADD25-Q01 | ENGINEERING_FIXTURE_PASS |  | ADD25-Q01 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD25-Q02 | ENGINEERING_FIXTURE_PASS |  | ADD25-Q02 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD25-Q03 | ENGINEERING_FIXTURE_PASS |  | ADD25-Q03 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD25-Q04 | ENGINEERING_FIXTURE_PASS |  | ADD25-Q04 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD25-Q05 | ENGINEERING_FIXTURE_PASS |  | ADD25-Q05 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD25-P01 | ENGINEERING_FIXTURE_PASS |  | ADD25-P01 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P02 | ENGINEERING_FIXTURE_PASS |  | ADD25-P02 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P03 | ENGINEERING_FIXTURE_PASS |  | ADD25-P03 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; ? | 2 |
| ADD25-P04 | ENGINEERING_FIXTURE_PASS |  | ADD25-P04 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P05 | ENGINEERING_FIXTURE_PASS |  | ADD25-P05 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-P06 | ENGINEERING_FIXTURE_PASS |  | ADD25-P06 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD25-R01 | ENGINEERING_FIXTURE_PASS |  | ADD25-R01 | vme.loop.stages, vme.state.handoff; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| ADD25-R02 | ENGINEERING_FIXTURE_PASS |  | ADD25-R02 | vme.loop.stages, vme.state.handoff; vme.reference.probe, vme.reference.frame_index, vme.reference.frames | 2 |
| ADD25-A01 | ENGINEERING_FIXTURE_PASS |  | ADD25-A01 | vme.loop.stages, vme.state.handoff | 1 |
| ADD25-A02 | ENGINEERING_FIXTURE_PASS |  | ADD25-A02 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| ADD25-L0-REAL | BLOCKED_AUTHORIZATION | PAID | Real first-15 per-frame VLM study (PHASE L0) | ? | 1 |
| ADD26-D01 | ENGINEERING_FIXTURE_PASS |  | ADD26-D01 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD26-D02 | ENGINEERING_FIXTURE_PASS |  | ADD26-D02 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 1 |
| ADD26-D03 | ENGINEERING_FIXTURE_PASS |  | ADD26-D03 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 2 |
| ADD26-D04 | ENGINEERING_FIXTURE_PASS |  | ADD26-D04 | vme.selection.first15, vme.selection.sixth, vme.spec_registry | 2 |
| ADD26-D05 | ENGINEERING_FIXTURE_PASS |  | ADD26-D05 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-Q01 | ENGINEERING_FIXTURE_PASS |  | ADD26-Q01 | vme.investigation.controller, vme.investigation.gaps | 2 |
| ADD26-Q02 | ENGINEERING_FIXTURE_PASS |  | ADD26-Q02 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-Q03 | ENGINEERING_FIXTURE_PASS |  | ADD26-Q03 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-Q04 | ENGINEERING_FIXTURE_PASS |  | ADD26-Q04 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-Q05 | ENGINEERING_FIXTURE_PASS |  | ADD26-Q05 | vme.loop.stages, vme.state.handoff; vme.investigation.controller, vme.investigation.gaps; ? | 3 |
| ADD26-Q06 | ENGINEERING_FIXTURE_PASS |  | ADD26-Q06 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-F01 | ENGINEERING_FIXTURE_PASS |  | ADD26-F01 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 1 |
| ADD26-F02 | ENGINEERING_FIXTURE_PASS |  | ADD26-F02 | vme.vision.runner, vme.vision.contracts, vme.vision.providers | 6 |
| ADD26-F03 | ENGINEERING_FIXTURE_PASS |  | ADD26-F03 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-F04 | ENGINEERING_FIXTURE_PASS |  | ADD26-F04 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-S01 | ENGINEERING_FIXTURE_PASS |  | ADD26-S01 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-S02 | ENGINEERING_FIXTURE_PASS |  | ADD26-S02 | vme.style.decisions, vme.investigation.evidence | 1 |
| ADD26-P01 | ENGINEERING_FIXTURE_PASS |  | ADD26-P01 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD26-P02 | ENGINEERING_FIXTURE_PASS |  | ADD26-P02 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD26-P03 | ENGINEERING_FIXTURE_PASS |  | ADD26-P03 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.investigation.controller, vme.investigation.gaps | 2 |
| ADD26-I01 | ENGINEERING_FIXTURE_PASS |  | ADD26-I01 | vme.investigation.controller, vme.investigation.gaps | 1 |
| ADD26-I02 | ENGINEERING_FIXTURE_PASS |  | ADD26-I02 | vme.review.approvals, vme.review.server, vme.render.renderer; vme.loop.stages, vme.state.handoff | 2 |
| ADD26-I03 | ENGINEERING_FIXTURE_PASS |  | ADD26-I03 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| ADD26-R01 | ENGINEERING_FIXTURE_PASS |  | ADD26-R01 | vme.loop.stages, vme.state.handoff; ? | 6 |
| ADD26-R02 | ENGINEERING_FIXTURE_PASS |  | ADD26-R02 | vme.providers.gateway, vme.providers.runware, vme.providers.authorization, vme.providers.capabilities; vme.vision.runner, vme.vision.contracts, vme.vision.providers | 2 |
| ADD26-A01 | FAIL |  | ADD26-A01 | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.loop.stages, vme.state.handoff | 2 |
| ADD26-A02 | ENGINEERING_FIXTURE_PASS |  | ADD26-A02 | vme.review.approvals, vme.review.server, vme.render.renderer | 1 |
| ADD26-S0S9 | REAL_PATH_WIRED_UNTESTED |  | ADD26-S0S9 | vme.loop.stages, vme.state.handoff; ? | 4 |
| ADD27-1 | ENGINEERING_FIXTURE_PASS |  | VisualModelCoverageLedger typed per schema | vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-2 | ENGINEERING_FIXTURE_PASS |  | READY_FOR_ORIGINAL_IMAGE_TRIAL scoped/provisional | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-3 | ENGINEERING_FIXTURE_PASS |  | Investigator finds multiple gaps; re-review after each fix | vme.style.coverage, vme.style.provenance, vme.skills.skill; ? | 3 |
| ADD27-4 | ENGINEERING_FIXTURE_PASS |  | Missing face/viewpoint; colour w/o light/world link; disconnected world/camera | vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-5 | ENGINEERING_FIXTURE_PASS |  | Joint-relation fixtures incl. pose/contact+lighting and all-NA contradiction | vme.style.coverage, vme.style.provenance, vme.skills.skill | 3 |
| ADD27-6 | ENGINEERING_FIXTURE_PASS |  | Model-authored clause blocked at observation→skill boundary | vme.style.coverage, vme.style.provenance, vme.skills.skill; ? | 3 |
| ADD27-7 | ENGINEERING_FIXTURE_PASS |  | Every appearance-affecting provider field classified (Interface II) | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-8 | ENGINEERING_FIXTURE_PASS |  | Lost skill clause in payload fails with before/after bytes | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway | 1 |
| ADD27-9 | ENGINEERING_FIXTURE_PASS |  | Free-text style via brief rejected | vme.compiler.compiler, vme.compiler.brief, vme.skills.skill, vme.providers.gateway; vme.style.coverage, vme.style.provenance, vme.skills.skill | 2 |
| ADD27-10 | ENGINEERING_FIXTURE_PASS |  | Unexpected phenomenon → dynamic extension | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-11 | ENGINEERING_FIXTURE_PASS |  | SOURCE_FACT/INFERRED/ENGINEERING distinctions recorded | vme.style.coverage, vme.style.provenance, vme.skills.skill; ? | 2 |
| ADD27-12 | ENGINEERING_FIXTURE_PASS |  | Ungoverned output appearance not credited to skill | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| ADD27-13 | ENGINEERING_FIXTURE_PASS |  | Provenance DAG lineage | vme.style.coverage, vme.style.provenance, vme.skills.skill; ? | 2 |
| ADD27-14 | ENGINEERING_FIXTURE_PASS |  | Crash during completeness/provenance commit recovers | vme.style.coverage, vme.style.provenance, vme.skills.skill | 1 |
| AUDIT-P0-1 | NOT_IMPLEMENTED |  | REAL loop connected S0–S9 (no unconditional blocks; providers injected) |  | 0 |
| AUDIT-P0-2 | NOT_IMPLEMENTED | PAID | Concrete vision provider integration with response conversion and reconciliation |  | 0 |
| AUDIT-P0-3 | ART_QUALITY_UNPROVEN | ART | Evidence→decision→skill authoring from persisted witnesses (no lexical proof) |  | 0 |
| AUDIT-P0-4 | NOT_IMPLEMENTED |  | Multi-gap controller with completeness recomputation over the scoped scene |  | 0 |
| AUDIT-P0-5 | REAL_PATH_WIRED_UNTESTED | HUMAN | Source identities quarantined until user confirmation; resolution reported | ? | 1 |
| AUDIT-P0-6 | ART_QUALITY_UNPROVEN | PAID+ART+HUMAN | Runware + character asset creation + art/asset/video human review paths |  | 0 |
