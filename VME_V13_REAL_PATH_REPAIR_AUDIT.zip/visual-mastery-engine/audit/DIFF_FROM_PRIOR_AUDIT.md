# Differences from the prior audit

Prior audit ZIP SHA256 `7fa6ad8e5ff9a3759801bd6bd7a7505a6c89e17a64036920cbee0829e37d837f` = commit `6d794c9`.

```
D	audit_export.out
M	tests/conftest.py
M	tests/test_loop_handoff.py
A	tests/test_real_path.py
M	vme/audit/docs.py
M	vme/audit/export.py
A	vme/audit/repair.py
M	vme/audit/requirements.py
M	vme/cli.py
A	vme/cli_real.py
M	vme/compiler/brief.py
M	vme/compiler/compiler.py
M	vme/investigation/controller.py
A	vme/loop/human.py
A	vme/loop/real.py
M	vme/loop/stages.py
M	vme/providers/gateway.py
M	vme/providers/runware.py
M	vme/reference/frames.py
A	vme/reference/roles.py
M	vme/review/approvals.py
M	vme/review/server.py
A	vme/skills/runtime.py
A	vme/style/authoring.py
M	vme/style/coverage.py
M	vme/style/decisions.py
A	vme/testing/__init__.py
A	vme/testing/drill.py
A	vme/testing/simulated_anthropic.py
A	vme/vision/claude_adapter.py
M	vme/vision/runner.py

```

```
 audit_export.out                   |  19 -
 tests/conftest.py                  |   1 +
 tests/test_loop_handoff.py         |  13 +-
 tests/test_real_path.py            | 238 ++++++++++++
 vme/audit/docs.py                  | 409 ++++++++++----------
 vme/audit/export.py                |  27 +-
 vme/audit/repair.py                | 122 ++++++
 vme/audit/requirements.py          | 275 ++++++-------
 vme/cli.py                         |  24 +-
 vme/cli_real.py                    |  85 ++++
 vme/compiler/brief.py              |  13 +-
 vme/compiler/compiler.py           |   3 +-
 vme/investigation/controller.py    |   2 +-
 vme/loop/human.py                  | 103 +++++
 vme/loop/real.py                   | 767 +++++++++++++++++++++++++++++++++++++
 vme/loop/stages.py                 |  17 +-
 vme/providers/gateway.py           |   7 +-
 vme/providers/runware.py           | 149 +++----
 vme/reference/frames.py            | 316 ++++++++-------
 vme/reference/roles.py             |  79 ++++
 vme/review/approvals.py            | 352 ++++++++---------
 vme/review/server.py               | 208 +++++-----
 vme/skills/runtime.py              |  36 ++
 vme/style/authoring.py             | 190 +++++++++
 vme/style/coverage.py              | 689 ++++++++++++++++-----------------
 vme/style/decisions.py             |  10 +-
 vme/testing/__init__.py            |   0
 vme/testing/drill.py               | 158 ++++++++
 vme/testing/simulated_anthropic.py | 184 +++++++++
 vme/vision/claude_adapter.py       | 197 ++++++++++
 vme/vision/runner.py               |  20 +-
 31 files changed, 3488 insertions(+), 1225 deletions(-)

```
