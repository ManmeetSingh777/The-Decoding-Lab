# Next agent handoff

1. Read `CONTINUE_HERE.md`, then the structured records (`workspace/store/vme.sqlite`, `workspace/state/*.json`) — not chat history.
2. Re-verify sources by SHA256 (`vme sources probe --folder <dir>`); STOP if bytes differ (`SOURCE_HASH_MISMATCH`).
3. Run `pytest -q tests` and `vme status --detailed`; confirm `PAID_VLM_FRAMES_SEEN=0`, `RUNWARE_REAL_CALLS=0`.
4. Do not start paid work. First tasks after the user's approval: (a) choose a VLM provider and record a verified capability snapshot;
   (b) Runware consented probe with the user-confirmed AIR id; (c) human/VLM candidate rationales → `vme selection propose`.
5. Hidden reasoning from this session is not transferable; only committed records are. Uncommitted work = UNRESOLVED.
Recomputed next operation: `{"kind": "AWAIT_HUMAN_DECISIONS", "pending": ["lock the sixth volcano\u2192logo interval from the local witness packet (vme selection sixth-lock ...)", "loop REAL-OFFLINE-1 stopped at S0: NO_VISUAL_RATIONALE_CANDIDATES: real candidates need HUMAN or authorized VLM whole-artwork witness statements before selection (ADD25-S05)", "loop REAL-001 stopped at S0: SOURCE_ROLES_UNCONFIRMED"], "command": "vme status --detailed   # then the user decides; no paid work without vme authorize"}`
